#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
DEFAULT_ROOT = SCRIPT_DIR.parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

import canonical
import schema_registry


class RuntimeVerificationError(RuntimeError):
    pass


def sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def sha256_file(path: Path) -> str:
    if path.is_symlink() or not path.is_file():
        raise RuntimeVerificationError(
            f"RUNTIME_FILE_MISSING_OR_UNSAFE:{path}"
        )
    return sha256_bytes(path.read_bytes())


def load_object(path: Path, label: str) -> dict[str, Any]:
    if path.is_symlink() or not path.is_file():
        raise RuntimeVerificationError(f"{label}_MISSING_OR_UNSAFE")
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise RuntimeVerificationError(f"{label}_INVALID_JSON") from exc
    if not isinstance(value, dict):
        raise RuntimeVerificationError(f"{label}_INVALID")
    return value


def parse_sha256sums(path: Path) -> dict[str, str]:
    if path.is_symlink() or not path.is_file():
        raise RuntimeVerificationError("RUNTIME_SHA256SUMS_MISSING_OR_UNSAFE")
    entries: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        parts = line.split(None, 1)
        if len(parts) != 2 or len(parts[0]) != 64:
            raise RuntimeVerificationError("RUNTIME_SHA256SUMS_LINE_INVALID")
        try:
            int(parts[0], 16)
        except ValueError as exc:
            raise RuntimeVerificationError(
                "RUNTIME_SHA256SUMS_DIGEST_INVALID"
            ) from exc
        relative = parts[1].lstrip("*")
        candidate = Path(relative)
        if (
            candidate.is_absolute()
            or ".." in candidate.parts
            or relative.startswith("./")
            or "\\" in relative
            or relative in entries
        ):
            raise RuntimeVerificationError("RUNTIME_SHA256SUMS_PATH_INVALID")
        entries[relative] = parts[0]
    return entries


def schema_manifest(root: Path, files: dict[str, str]) -> dict[str, str]:
    result: dict[str, str] = {}
    for relative in sorted(files):
        if not relative.startswith("schemas/") or not relative.endswith(".json"):
            continue
        document = load_object(root / relative, f"SCHEMA:{relative}")
        result[relative] = canonical.canonical_sha256(document)
    return result
def verify_runtime(
    root: Path = DEFAULT_ROOT,
    *,
    expected_artifact_sha256: str | None = None,
) -> dict[str, Any]:
    root = root.resolve()
    manifest = load_object(root / "runtime-manifest.json", "RUNTIME_MANIFEST")
    family, version = schema_registry.assert_valid_document(manifest)
    if (family, version) != ("consumer-runtime", "1.0.0"):
        raise RuntimeVerificationError("RUNTIME_MANIFEST_FAMILY_INVALID")

    files = manifest.get("files")
    if not isinstance(files, dict) or not files:
        raise RuntimeVerificationError("RUNTIME_MANIFEST_FILES_INVALID")
    if any(
        relative.startswith("trust/")
        or relative.startswith("releases/")
        or (
            Path(relative).name.startswith("ksss-trust-root-")
            and Path(relative).name.endswith(".json")
        )
        for relative in files
    ):
        raise RuntimeVerificationError("RUNTIME_OWNS_TRUST_ANCHOR")

    actual_files = {
        path.relative_to(root).as_posix()
        for path in root.rglob("*")
        if path.is_file()
        and path.name not in {"runtime-manifest.json", "SHA256SUMS"}
        and not (
            "__pycache__" in path.parts
            and path.suffix == ".pyc"
        )
    }
    if actual_files != set(files):
        raise RuntimeVerificationError("RUNTIME_FILE_SET_MISMATCH")

    for relative, expected in sorted(files.items()):
        actual = sha256_file(root / relative)
        if actual != expected:
            raise RuntimeVerificationError(
                f"RUNTIME_FILE_DIGEST_MISMATCH:{relative}"
            )

    aggregate = canonical.canonical_sha256(files)
    if aggregate != manifest["runtime_files_digest"]:
        raise RuntimeVerificationError("RUNTIME_FILES_DIGEST_MISMATCH")

    sums = parse_sha256sums(root / "SHA256SUMS")
    expected_sum_files = set(files) | {"runtime-manifest.json"}
    if set(sums) != expected_sum_files:
        raise RuntimeVerificationError("RUNTIME_SHA256SUMS_FILE_SET_MISMATCH")
    for relative, expected in sorted(sums.items()):
        actual = sha256_file(root / relative)
        if actual != expected:
            raise RuntimeVerificationError(
                f"RUNTIME_SHA256SUMS_MISMATCH:{relative}"
            )

    embedded_schema_digest = canonical.canonical_sha256(
        schema_manifest(root, files)
    )
    if embedded_schema_digest != manifest["schema_digest"]:
        raise RuntimeVerificationError("RUNTIME_SCHEMA_DIGEST_MISMATCH")

    catalog_path = root / "standards/KSSS/CONTROL-CATALOG.yaml"
    catalog = load_object(catalog_path, "CONTROL_CATALOG")
    if (
        canonical.canonical_sha256(catalog)
        != manifest["control_catalog_digest"]
    ):
        raise RuntimeVerificationError("RUNTIME_CONTROL_CATALOG_DIGEST_MISMATCH")

    if manifest["network_required_for_execution"] is not False:
        raise RuntimeVerificationError("RUNTIME_NETWORK_REQUIREMENT_INVALID")
    if manifest["external_ksss_checkout_required"] is not False:
        raise RuntimeVerificationError("RUNTIME_EXTERNAL_CHECKOUT_INVALID")
    if manifest["crypto_verification_phase"] != "ADOPTION_OR_UPDATE":
        raise RuntimeVerificationError("RUNTIME_CRYPTO_PHASE_INVALID")

    result: dict[str, Any] = {
        "schema": "ksss-consumer-runtime-verification-v1",
        "status": "PASS",
        "ksss_release": manifest["ksss_release"],
        "ksss_source_sha": manifest["ksss_source_sha"],
        "runtime_sequence": manifest["runtime_sequence"],
        "runtime_files_digest": aggregate,
        "policy_bundle_digest": manifest["policy_bundle_digest"],
        "schema_digest": manifest["schema_digest"],
        "control_catalog_digest": manifest["control_catalog_digest"],
        "file_count": len(files),
        "network_required_for_execution": False,
        "external_ksss_checkout_required": False,
    }
    if expected_artifact_sha256 is not None:
        if len(expected_artifact_sha256) != 64:
            raise RuntimeVerificationError("EXPECTED_ARTIFACT_SHA256_INVALID")
        result["expected_artifact_sha256"] = expected_artifact_sha256
    return result
def parser() -> argparse.ArgumentParser:
    value = argparse.ArgumentParser(prog="ksss-runtime-verify")
    value.add_argument("--root", type=Path, default=DEFAULT_ROOT)
    value.add_argument("--expected-artifact-sha256")
    value.add_argument("--output", type=Path)
    return value


def main() -> int:
    args = parser().parse_args()
    try:
        result = verify_runtime(
            args.root,
            expected_artifact_sha256=args.expected_artifact_sha256,
        )
    except (
        OSError,
        ValueError,
        RuntimeVerificationError,
        schema_registry.SchemaDispatchError,
    ) as exc:
        print(json.dumps({"status": "FAIL", "reason": str(exc)}, sort_keys=True))
        return 1

    payload = json.dumps(result, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(payload, encoding="utf-8")
    print(payload, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
