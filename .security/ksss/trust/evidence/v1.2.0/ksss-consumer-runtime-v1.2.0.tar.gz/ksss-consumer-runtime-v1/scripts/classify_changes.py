#!/usr/bin/env python3
from __future__ import annotations
import argparse, subprocess
from pathlib import Path, PurePosixPath

ROOT=Path(__file__).resolve().parents[1]
DEPENDENCY_NAMES={"pyproject.toml","poetry.lock","uv.lock","requirements.txt","package.json",
"package-lock.json","pnpm-lock.yaml","yarn.lock","Cargo.toml","Cargo.lock","go.mod","go.sum",
"composer.json","composer.lock","Gemfile","Gemfile.lock"}
THREAT_MODEL_NAMES={"threat-model.yaml","threat-model.yml","threat-model.json","THREAT_MODEL.md"}
ARTIFACT_PREFIXES=("dist/","artifacts/","release-assets/")
POLICY_PREFIXES=("profiles/","schemas/","safety-contracts/","mappings/","standards/KSSS/","exceptions/",".security/","maintenance/ksss/")
RUNTIME_PREFIXES=("infra/","deploy/","k8s/","terraform/")

def git_lines(*args):
    out=subprocess.check_output(["git","-C",str(ROOT),*args],text=True)
    return [x for x in out.splitlines() if x.strip()]

def classify_paths(paths):
    kinds=set(); generic=False
    for raw in paths:
        p=raw.replace("\\","/")
        if p.startswith("./"): p=p[2:]
        name=PurePosixPath(p).name
        if not p: continue
        if p.startswith(".github/workflows/"):
            kinds.add("WORKFLOW_CHANGE"); continue
        if name in DEPENDENCY_NAMES or (name.startswith("requirements") and name.endswith(".txt")):
            kinds.add("DEPENDENCY_CHANGE"); continue
        if name in THREAT_MODEL_NAMES:
            kinds.add("THREAT_MODEL_CHANGE"); continue
        if p.startswith(POLICY_PREFIXES):
            kinds.add("POLICY_CHANGE"); continue
        if p.startswith(ARTIFACT_PREFIXES):
            kinds.add("ARTIFACT_CHANGE"); continue
        if p.startswith(RUNTIME_PREFIXES) or name in {"Dockerfile","docker-compose.yml","docker-compose.yaml"}:
            kinds.add("RUNTIME_CONFIG_CHANGE"); continue
        if "authorization" in p.lower() or name=="CODEOWNERS":
            kinds.add("AUTHORIZATION_CHANGE"); continue
        generic=True
    if generic and not kinds: kinds.add("CODE_ONLY_CHANGE")
    return sorted(kinds)

def changed_paths(base,head):
    return git_lines("diff","--name-only",base,head)

def worktree_paths():
    paths=set(git_lines("diff","--name-only"))
    paths.update(git_lines("diff","--cached","--name-only"))
    paths.update(git_lines("ls-files","--others","--exclude-standard"))
    return sorted(paths)

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--path",action="append")
    p.add_argument("--base"); p.add_argument("--head")
    p.add_argument("--worktree",action="store_true")
    args=p.parse_args()
    paths=list(args.path or [])
    if args.base or args.head:
        if not (args.base and args.head): p.error("--base and --head must be used together")
        paths.extend(changed_paths(args.base,args.head))
    if args.worktree: paths.extend(worktree_paths())
    if not paths: p.error("provide --path, --base/--head, or --worktree")
    for kind in classify_paths(paths): print(kind)

if __name__=="__main__":
    main()
