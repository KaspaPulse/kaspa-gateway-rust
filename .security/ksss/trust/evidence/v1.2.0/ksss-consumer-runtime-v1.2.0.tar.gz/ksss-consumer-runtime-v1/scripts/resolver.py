#!/usr/bin/env python3
from __future__ import annotations

import re
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from canonical import canonical_sha256
from schema_registry import assert_valid_document

PROFILE_NAMES = {"light", "medium", "full", "deep", "spider"}
RESULTS = {"EQUIVALENT", "STRICTER", "WEAKER", "INCOMPARABLE"}


class ResolverError(ValueError):
    pass


def _numeric(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def _as_set(value: Any, label: str) -> set[Any]:
    if not isinstance(value, (list, tuple, set, frozenset)):
        raise ResolverError(f"{label}: set semantics require an array/set")
    try:
        return set(value)
    except TypeError as exc:
        raise ResolverError(f"{label}: set values must be hashable") from exc


def compare_strengthening(
    baseline: Any,
    local: Any,
    semantics: str | dict[str, Any],
) -> str:
    if baseline == local:
        return "EQUIVALENT"

    kind = semantics if isinstance(semantics, str) else semantics.get("kind")
    if kind == "HIGHER":
        if not (_numeric(baseline) and _numeric(local)):
            raise ResolverError("HIGHER semantics require numeric values")
        return "STRICTER" if local > baseline else "WEAKER"
    if kind == "LOWER":
        if not (_numeric(baseline) and _numeric(local)):
            raise ResolverError("LOWER semantics require numeric values")
        return "STRICTER" if local < baseline else "WEAKER"

    if kind in {"SUBSET", "SUPERSET"}:
        base_set = _as_set(baseline, kind)
        local_set = _as_set(local, kind)
        if kind == "SUBSET":
            if local_set < base_set:
                return "STRICTER"
            if base_set < local_set:
                return "WEAKER"
        else:
            if local_set > base_set:
                return "STRICTER"
            if base_set > local_set:
                return "WEAKER"
        return "INCOMPARABLE"

    if kind in {"TRUE_ONLY", "FALSE_ONLY"}:
        if not isinstance(baseline, bool) or not isinstance(local, bool):
            raise ResolverError(f"{kind} semantics require booleans")
        stricter = True if kind == "TRUE_ONLY" else False
        if local is stricter and baseline is not stricter:
            return "STRICTER"
        return "WEAKER"

    if kind == "CUSTOM_PARTIAL_ORDER":
        if not isinstance(semantics, dict):
            raise ResolverError(
                "CUSTOM_PARTIAL_ORDER requires an explicit dominates relation"
            )
        dominates = semantics.get("dominates")
        if not isinstance(dominates, dict):
            raise ResolverError(
                "CUSTOM_PARTIAL_ORDER requires an explicit dominates relation"
            )
        local_dominates = set(dominates.get(str(local), []))
        base_dominates = set(dominates.get(str(baseline), []))
        if str(baseline) in local_dominates:
            return "STRICTER"
        if str(local) in base_dominates:
            return "WEAKER"
        return "INCOMPARABLE"

    raise ResolverError(f"unknown strengthening semantics {kind!r}")


def _required_controls(source: dict[str, Any], label: str) -> set[str]:
    values = source.get("required_controls", [])
    if not isinstance(values, list) or not all(isinstance(v, str) for v in values):
        raise ResolverError(f"{label}.required_controls must be an array of strings")
    return set(values)


def _parse_explicit_time(value: str) -> datetime:
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except Exception as exc:
        raise ResolverError(
            f"explicit time must be ISO-8601 with timezone: {value!r}"
        ) from exc
    if parsed.tzinfo is None:
        raise ResolverError("explicit time must include a timezone")
    return parsed


def _parse_exception_expiry(value: str) -> datetime:
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
        try:
            day = datetime.fromisoformat(value).replace(tzinfo=timezone.utc)
        except Exception as exc:
            raise ResolverError(f"invalid legacy exception expiry: {value!r}") from exc
        return day + timedelta(days=1)
    return _parse_explicit_time(value)


def _validate_control_references(
    control_ids: set[str],
    known: set[str],
    label: str,
) -> None:
    unknown = control_ids - known
    if unknown:
        raise ResolverError(f"{label}: unknown controls {sorted(unknown)}")


def _active_exceptions(
    exceptions: list[dict[str, Any]],
    known: set[str],
    base_controls: dict[str, Any],
    explicit_time: str | None,
) -> dict[str, dict[str, Any]]:
    if not exceptions:
        return {}
    if explicit_time is None:
        raise ResolverError(
            "time-sensitive exception evaluation requires explicit_time"
        )
    now = _parse_explicit_time(explicit_time)
    active: dict[str, dict[str, Any]] = {}
    for item in exceptions:
        exception_id = item.get("exception_id", item.get("id"))
        control_id = item.get("control_id", item.get("control"))
        required = (
            "scope",
            "reason",
            "risk_owner",
            "compensating_controls",
            "approval",
            "created_at",
            "expires_at",
            "evidence",
        )
        missing = [name for name in required if not item.get(name)]
        if not exception_id:
            missing.insert(0, "exception_id")
        if not control_id:
            missing.insert(0, "control_id")
        if missing:
            raise ResolverError(
                f"exception {exception_id!r}: missing required overlay fields {missing}"
            )
        if control_id not in known:
            raise ResolverError(
                f"exception {exception_id!r}: unknown control {control_id!r}"
            )
        if control_id in active:
            raise ResolverError(
                f"conflict: multiple exceptions target {control_id}"
            )
        if base_controls[control_id].get("exception_allowed") is not True:
            raise ResolverError(
                f"exception {exception_id!r}: control {control_id} forbids exceptions"
            )
        expiry = _parse_exception_expiry(item["expires_at"])
        if expiry <= now:
            raise ResolverError(
                f"exception {exception_id!r}: EXCEPTION_STATUS=EXPIRED; "
                f"CONTROL_STATUS=FAIL"
            )
        normalized = dict(item)
        normalized["id"] = exception_id
        normalized["control"] = control_id
        active[control_id] = normalized
    return active


def resolve_effective_policy(
    *,
    base_policy: dict[str, Any],
    risk_classification: dict[str, Any],
    applicability: dict[str, Any],
    repository_profile: dict[str, Any],
    local_strengthening: dict[str, Any],
    exceptions: list[dict[str, Any]],
    explicit_time: str | None = None,
    resolver_version: str = "1.0.0",
) -> dict[str, Any]:
    repository = base_policy.get("repository")
    if not isinstance(repository, str) or not repository:
        raise ResolverError("base_policy.repository is required")

    profile_name = repository_profile.get("profile")
    if profile_name not in PROFILE_NAMES:
        raise ResolverError(f"unknown profile {profile_name!r}")

    family, _ = assert_valid_document(local_strengthening)
    if family != "local-strengthening":
        raise ResolverError("local_strengthening has the wrong schema family")
    if local_strengthening.get("repository") != repository:
        raise ResolverError("local_strengthening repository mismatch")

    base_controls = base_policy.get("controls")
    if not isinstance(base_controls, dict) or not base_controls:
        raise ResolverError("base_policy.controls must be a non-empty object")
    known = set(base_controls)

    required = {
        control_id
        for control_id, control in base_controls.items()
        if isinstance(control, dict) and control.get("required") is True
    }
    for label, source in (
        ("risk_classification", risk_classification),
        ("applicability", applicability),
        ("repository_profile", repository_profile),
    ):
        selected = _required_controls(source, label)
        _validate_control_references(selected, known, label)
        required.update(selected)

    resolved_controls: dict[str, dict[str, Any]] = {}
    for control_id, control in base_controls.items():
        if not isinstance(control, dict):
            raise ResolverError(f"base control {control_id} must be an object")
        parameters = control.get("parameters", {})
        if not isinstance(parameters, dict):
            raise ResolverError(
                f"base control {control_id}.parameters must be an object"
            )
        values: dict[str, Any] = {}
        for name, definition in parameters.items():
            if not isinstance(definition, dict):
                raise ResolverError(
                    f"base parameter {control_id}.{name} must be an object"
                )
            if "value" not in definition or "strengthening" not in definition:
                raise ResolverError(
                    f"base parameter {control_id}.{name} lacks value/strengthening"
                )
            values[name] = definition["value"]
        resolved_controls[control_id] = {
            "required": control_id in required,
            "parameters": values,
        }


    for control_id, change in local_strengthening.get("controls", {}).items():
        if control_id not in known:
            raise ResolverError(
                f"local_strengthening: unknown control {control_id}"
            )
        if change.get("required") is True:
            required.add(control_id)
            resolved_controls[control_id]["required"] = True

        for name, local_item in change.get("parameters", {}).items():
            base_parameters = base_controls[control_id].get("parameters", {})
            if name not in base_parameters:
                raise ResolverError(
                    f"unresolved reference: {control_id}.{name}"
                )
            base_definition = base_parameters[name]
            local_value = local_item["value"]
            result = compare_strengthening(
                base_definition["value"],
                local_value,
                base_definition["strengthening"],
            )
            if result == "WEAKER":
                raise ResolverError(
                    f"{control_id}.{name}: local policy is weaker than baseline"
                )
            if result == "INCOMPARABLE":
                raise ResolverError(
                    f"{control_id}.{name}: local policy is incomparable; "
                    "explicit review required"
                )
            resolved_controls[control_id]["parameters"][name] = local_value

    active = _active_exceptions(
        exceptions,
        known,
        base_controls,
        explicit_time,
    )
    for control_id, item in active.items():
        resolved_controls[control_id]["exception_id"] = item["id"]
        resolved_controls[control_id]["control_status"] = "EXCEPTED"

    inputs = {
        "base_policy": base_policy,
        "risk_classification": risk_classification,
        "applicability": applicability,
        "repository_profile": repository_profile,
        "local_strengthening": local_strengthening,
        "exceptions": exceptions,
        "resolver_version": resolver_version,
    }
    if exceptions:
        inputs["resolution_time_input"] = explicit_time

    input_digest = canonical_sha256(inputs)
    effective = {
        "schema_family": "effective-policy",
        "schema_version": "1.0.0",
        "repository": repository,
        "resolver_version": resolver_version,
        "policy_resolution_inputs_digest": input_digest,
        "required_controls": sorted(required),
        "controls": {
            control_id: resolved_controls[control_id]
            for control_id in sorted(resolved_controls)
        },
        "active_exceptions": sorted(
            item["id"] for item in active.values()
        ),
    }
    if exceptions:
        effective["resolution_time_input"] = explicit_time

    digest_payload = dict(effective)
    effective_digest = canonical_sha256(digest_payload)
    effective["effective_policy_digest"] = effective_digest
    assert_valid_document(effective)
    return effective


def policy_identity_evidence(
    effective_policy: dict[str, Any],
    *,
    source_sha: str,
    tree_hash: str,
    ksss_release: str,
    ksss_source_sha: str,
    ksss_bundle_digest: str,
    ksss_schema_digest: str,
    trust_root_version: str,
    trust_root_digest: str,
    validator_digest: str,
    resolver_digest: str,
    risk_classification_digest: str,
    applicability_digest: str,
    repository_profile_digest: str,
    local_strengthening_digest: str,
    exception_set_digest: str,
) -> dict[str, Any]:
    evidence = {
        "SOURCE_SHA": source_sha,
        "TREE_HASH": tree_hash,
        "KSSS_RELEASE": ksss_release,
        "KSSS_SOURCE_SHA": ksss_source_sha,
        "KSSS_BUNDLE_DIGEST": ksss_bundle_digest,
        "KSSS_SCHEMA_DIGEST": ksss_schema_digest,
        "TRUST_ROOT_VERSION": trust_root_version,
        "TRUST_ROOT_DIGEST": trust_root_digest,
        "VALIDATOR_DIGEST": validator_digest,
        "RESOLVER_DIGEST": resolver_digest,
        "RISK_CLASSIFICATION_DIGEST": risk_classification_digest,
        "APPLICABILITY_DIGEST": applicability_digest,
        "REPOSITORY_PROFILE_DIGEST": repository_profile_digest,
        "LOCAL_STRENGTHENING_DIGEST": local_strengthening_digest,
        "EXCEPTION_SET_DIGEST": exception_set_digest,
        "POLICY_RESOLUTION_INPUTS_DIGEST": effective_policy[
            "policy_resolution_inputs_digest"
        ],
        "EFFECTIVE_POLICY_DIGEST": effective_policy[
            "effective_policy_digest"
        ],
    }
    if "resolution_time_input" in effective_policy:
        evidence["RESOLUTION_TIME_INPUT"] = effective_policy[
            "resolution_time_input"
        ]
    return evidence


__all__ = [
    "RESULTS",
    "ResolverError",
    "compare_strengthening",
    "policy_identity_evidence",
    "resolve_effective_policy",
]
