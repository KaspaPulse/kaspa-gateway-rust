#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from canonical import canonical_sha256
from schema_registry import assert_valid_document


class BundleVerificationError(ValueError):
    pass


def _parse_explicit_time(value: str, label: str) -> datetime:
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except Exception as exc:
        raise BundleVerificationError(
            f"{label}: invalid ISO-8601 timestamp {value!r}"
        ) from exc
    if parsed.tzinfo is None:
        raise BundleVerificationError(
            f"{label}: timestamp must include an explicit timezone"
        )
    return parsed


def verify_trust_root(
    trust_root: dict[str, Any],
    *,
    explicit_time: str,
) -> None:
    family, _ = assert_valid_document(trust_root)
    if family != "trust-root":
        raise BundleVerificationError("wrong trust-root schema family")

    now = _parse_explicit_time(explicit_time, "explicit_time")
    valid_from = _parse_explicit_time(
        trust_root["valid_from"],
        "trust_root.valid_from",
    )
    expires_at = _parse_explicit_time(
        trust_root["expires_at"],
        "trust_root.expires_at",
    )
    if now < valid_from:
        raise BundleVerificationError("trust metadata is not yet valid")
    if now >= expires_at:
        raise BundleVerificationError("trust metadata is expired")


def verify_bundle(
    *,
    bundle_bytes: bytes,
    bundle_metadata: dict[str, Any],
    attestation: dict[str, Any],
    trust_root: dict[str, Any],
    adoption: dict[str, Any],
    explicit_time: str,
) -> dict[str, str]:
    adoption_family, _ = assert_valid_document(adoption)
    if adoption_family != "ksss-adoption":
        raise BundleVerificationError("wrong adoption schema family")
    verify_trust_root(trust_root, explicit_time=explicit_time)

    forbidden = {
        "trust_root",
        "trusted_issuer",
        "trusted_signer",
        "trusted_signer_or_workflow_identity",
    }
    owned = forbidden.intersection(bundle_metadata)
    if owned:
        raise BundleVerificationError(
            f"bundle must not define its own trust anchor: {sorted(owned)}"
        )

    digest = hashlib.sha256(bundle_bytes).hexdigest()
    if attestation.get("signature_or_attestation_verified") is not True:
        raise BundleVerificationError(
            "signature/attestation verification is not VERIFIED"
        )
    if attestation.get("subject_sha256") != digest:
        raise BundleVerificationError("attestation subject digest mismatch")
    if attestation.get("issuer") != trust_root["trusted_issuer"]:
        raise BundleVerificationError("wrong issuer")
    if (
        attestation.get("signer_or_workflow_identity")
        != trust_root["trusted_signer_or_workflow_identity"]
    ):
        raise BundleVerificationError("wrong signer/workflow identity")

    if digest != adoption["policy_bundle_digest"]:
        raise BundleVerificationError("wrong policy bundle digest")
    if bundle_metadata.get("digest") not in {None, digest}:
        raise BundleVerificationError("bundle metadata digest mismatch")

    if bundle_metadata.get("release") != adoption["ksss_release"]:
        raise BundleVerificationError("bundle release does not match adoption")
    if bundle_metadata.get("source_sha") != adoption["ksss_source_sha"]:
        raise BundleVerificationError("bundle source SHA does not match adoption")


    sequence = bundle_metadata.get("sequence")
    if not isinstance(sequence, int) or isinstance(sequence, bool):
        raise BundleVerificationError("bundle sequence must be an integer")
    if sequence < trust_root["minimum_allowed_ksss_sequence"]:
        raise BundleVerificationError("bundle sequence is below rollback floor")

    return {
        "TRUST_ROOT_VALID": "PASS",
        "SIGNER_VALID": "PASS",
        "ISSUER_VALID": "PASS",
        "DIGEST_VALID": "PASS",
        "SEQUENCE_ALLOWED": "PASS",
        "NOT_EXPIRED": "PASS",
        "BUNDLE_VERIFICATION": "PASS",
    }


def verify_root_rotation(
    *,
    previous_root: dict[str, Any],
    new_root: dict[str, Any],
    rotation_evidence: dict[str, Any],
) -> dict[str, str]:
    previous_family, _ = assert_valid_document(previous_root)
    new_family, _ = assert_valid_document(new_root)
    if previous_family != "trust-root" or new_family != "trust-root":
        raise BundleVerificationError("root rotation requires trust-root documents")

    mode = new_root["rotation_policy"]["mode"]
    if (
        new_root["minimum_allowed_ksss_sequence"]
        < previous_root["minimum_allowed_ksss_sequence"]
    ):
        raise BundleVerificationError(
            "trust-root rotation cannot lower the rollback floor"
        )
    if rotation_evidence.get("previous_root_version") != previous_root["root_version"]:
        raise BundleVerificationError("rotation evidence previous root mismatch")
    if rotation_evidence.get("new_root_version") != new_root["root_version"]:
        raise BundleVerificationError("rotation evidence new root mismatch")
    if rotation_evidence.get("new_root_digest") != canonical_sha256(new_root):
        raise BundleVerificationError("rotation evidence new root digest mismatch")
    if not rotation_evidence.get("reason"):
        raise BundleVerificationError("rotation reason is required")
    if not rotation_evidence.get("approval"):
        raise BundleVerificationError("rotation approval is required")
    if not rotation_evidence.get("effective_date"):
        raise BundleVerificationError("rotation effective date is required")
    if not rotation_evidence.get("recovery_procedure"):
        raise BundleVerificationError("rotation recovery procedure is required")

    if mode == "PREVIOUS_ROOT_AUTHORIZES_NEXT":
        if rotation_evidence.get("authorized_by_previous_root") is not True:
            raise BundleVerificationError(
                "new root is not authorized by previous root"
            )
    elif mode == "EMERGENCY_GOVERNED_RECOVERY":
        if rotation_evidence.get("emergency_governance_approved") is not True:
            raise BundleVerificationError(
                "emergency root recovery lacks explicit governance approval"
            )

    return {
        "TRUST_ROOT_CHANGE": "PASS",
        "ROTATION_EVIDENCE": "PASS",
    }


__all__ = [
    "BundleVerificationError",
    "verify_bundle",
    "verify_root_rotation",
    "verify_trust_root",
]
