#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import math
from decimal import Decimal
from pathlib import Path
from typing import Any


class CanonicalizationError(ValueError):
    pass


def _number_text(value: int | float | Decimal) -> str:
    if isinstance(value, bool):
        raise CanonicalizationError("boolean is not a numeric value here")
    if isinstance(value, float):
        if not math.isfinite(value):
            raise CanonicalizationError("non-finite numbers are forbidden")
        decimal_value = Decimal(str(value))
    elif isinstance(value, Decimal):
        if not value.is_finite():
            raise CanonicalizationError("non-finite numbers are forbidden")
        decimal_value = value
    else:
        decimal_value = Decimal(value)

    if decimal_value == 0:
        return "0"
    normalized = decimal_value.normalize()
    if normalized == normalized.to_integral():
        return format(normalized.quantize(Decimal(1)), "f")
    text = format(normalized, "f")
    if "." in text:
        text = text.rstrip("0").rstrip(".")
    return text


def canonical_text(value: Any) -> str:
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, (int, float, Decimal)):
        return _number_text(value)
    if isinstance(value, str):
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    if isinstance(value, list):
        return "[" + ",".join(canonical_text(item) for item in value) + "]"
    if isinstance(value, dict):
        if not all(isinstance(key, str) for key in value):
            raise CanonicalizationError("object keys must be strings")
        pairs = []
        for key in sorted(value):
            encoded_key = json.dumps(
                key,
                ensure_ascii=False,
                separators=(",", ":"),
            )
            pairs.append(encoded_key + ":" + canonical_text(value[key]))
        return "{" + ",".join(pairs) + "}"
    raise CanonicalizationError(
        f"unsupported canonical value type: {type(value).__name__}"
    )


def canonical_bytes(value: Any) -> bytes:
    return canonical_text(value).encode("utf-8")


def canonical_sha256(value: Any) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def load_json_compatible(path: Path) -> Any:
    try:
        return json.loads(
            path.read_text(encoding="utf-8"),
            parse_float=Decimal,
        )
    except Exception as exc:
        raise CanonicalizationError(
            f"{path}: invalid JSON-compatible YAML/JSON: {exc}"
        ) from exc


def canonical_file_sha256(path: Path) -> str:
    return canonical_sha256(load_json_compatible(path))


__all__ = [
    "CanonicalizationError",
    "canonical_bytes",
    "canonical_file_sha256",
    "canonical_sha256",
    "canonical_text",
    "load_json_compatible",
]
