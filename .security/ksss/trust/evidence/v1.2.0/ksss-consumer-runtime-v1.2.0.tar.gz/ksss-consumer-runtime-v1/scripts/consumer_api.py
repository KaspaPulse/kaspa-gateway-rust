#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, Iterable

SCRIPT_DIR = Path(__file__).resolve().parent
RUNTIME_ROOT = SCRIPT_DIR.parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

import bundle_verify
import canonical
import classify_changes
import knowledge
import resolver
import schema_registry

RUNTIME_API_VERSION = "1.0.0"
PROFILE_NAMES = {"light", "medium", "full", "deep", "spider"}


class ConsumerRuntimeError(RuntimeError):
    pass


def load_document(relative: str) -> dict[str, Any]:
    path = RUNTIME_ROOT / relative
    if path.is_symlink() or not path.is_file():
        raise ConsumerRuntimeError(f"RUNTIME_DOCUMENT_MISSING_OR_UNSAFE:{relative}")
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ConsumerRuntimeError(f"RUNTIME_DOCUMENT_INVALID:{relative}") from exc
    if not isinstance(value, dict):
        raise ConsumerRuntimeError(f"RUNTIME_DOCUMENT_NOT_OBJECT:{relative}")
    return value


def runtime_manifest() -> dict[str, Any]:
    return load_document("runtime-manifest.json")


def control_catalog() -> dict[str, Any]:
    return load_document("standards/KSSS/CONTROL-CATALOG.yaml")


def profile(name: str) -> dict[str, Any]:
    if name not in PROFILE_NAMES:
        raise ConsumerRuntimeError(f"UNKNOWN_PROFILE:{name}")
    return load_document(f"profiles/{name}.yaml")


def safety_contract(name: str) -> dict[str, Any]:
    if not name or "/" in name or "\\" in name:
        raise ConsumerRuntimeError("INVALID_SAFETY_CONTRACT_NAME")
    return load_document(f"safety-contracts/{name}.yaml")


def classify_paths(paths: Iterable[str]) -> list[str]:
    return classify_changes.classify_paths(list(paths))


def validate_document(document: dict[str, Any]) -> list[str]:
    return schema_registry.validate_document(document)


def assert_valid_document(document: dict[str, Any]) -> tuple[str, str]:
    return schema_registry.assert_valid_document(document)


def resolve_effective_policy(**kwargs: Any) -> dict[str, Any]:
    return resolver.resolve_effective_policy(**kwargs)


def lookup_known_failures(
    records: Iterable[dict[str, Any]],
    *,
    fingerprint: dict[str, Any],
    context: dict[str, Any],
    active_change_types: Iterable[str] = (),
) -> list[dict[str, Any]]:
    return knowledge.lookup_known_failures(
        records,
        fingerprint=fingerprint,
        context=context,
        active_change_types=active_change_types,
    )
def lookup_known_good_paths(
    records: Iterable[dict[str, Any]],
    *,
    operation_class: str,
    context: dict[str, Any],
    active_change_types: Iterable[str] = (),
) -> list[dict[str, Any]]:
    return knowledge.lookup_known_good_paths(
        records,
        operation_class=operation_class,
        context=context,
        active_change_types=active_change_types,
    )


def record_reusable(
    record: dict[str, Any],
    *,
    context: dict[str, Any],
    active_change_types: Iterable[str] = (),
) -> bool:
    return knowledge.record_reusable(
        record,
        context=context,
        active_change_types=active_change_types,
    )


def validate_diagnosis_sequence(
    events: Iterable[str],
    *,
    high_severity_production_incident: bool = False,
) -> str:
    return knowledge.validate_diagnosis_sequence(
        events,
        high_severity_production_incident=high_severity_production_incident,
    )


def learning_closeout(
    *,
    service_status: str,
    learning_status: str,
    durable_protections: Iterable[str],
) -> str:
    return knowledge.learning_closeout(
        service_status=service_status,
        learning_status=learning_status,
        durable_protections=durable_protections,
    )


def verify_bundle(**kwargs: Any) -> dict[str, str]:
    return bundle_verify.verify_bundle(**kwargs)


def verify_trust_root(
    trust_root: dict[str, Any],
    *,
    explicit_time: str,
) -> None:
    bundle_verify.verify_trust_root(
        trust_root,
        explicit_time=explicit_time,
    )


def canonical_sha256(value: Any) -> str:
    return canonical.canonical_sha256(value)


__all__ = [
    "ConsumerRuntimeError",
    "PROFILE_NAMES",
    "RUNTIME_API_VERSION",
    "RUNTIME_ROOT",
    "assert_valid_document",
    "canonical_sha256",
    "classify_paths",
    "control_catalog",
    "learning_closeout",
    "load_document",
    "lookup_known_failures",
    "lookup_known_good_paths",
    "profile",
    "record_reusable",
    "resolve_effective_policy",
    "runtime_manifest",
    "safety_contract",
    "validate_diagnosis_sequence",
    "validate_document",
    "verify_bundle",
    "verify_trust_root",
]
