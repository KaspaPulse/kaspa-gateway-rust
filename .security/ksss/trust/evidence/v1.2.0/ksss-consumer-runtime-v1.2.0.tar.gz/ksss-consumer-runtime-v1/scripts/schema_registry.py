#!/usr/bin/env python3
from __future__ import annotations

import json
import re
from datetime import datetime
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
OFFICIAL_CHANGE_TYPES = {
    "CODE_ONLY_CHANGE",
    "DEPENDENCY_CHANGE",
    "WORKFLOW_CHANGE",
    "POLICY_CHANGE",
    "ARTIFACT_CHANGE",
    "THREAT_MODEL_CHANGE",
    "AUTHORIZATION_CHANGE",
    "RUNTIME_CONFIG_CHANGE",
}


class SchemaDispatchError(ValueError):
    pass


def load_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise SchemaDispatchError(f"{path}: invalid JSON-compatible document: {exc}") from exc
    if not isinstance(value, dict):
        raise SchemaDispatchError(f"{path}: top level must be an object")
    return value


def load_registry() -> dict[str, Any]:
    return load_json(ROOT / "schemas" / "schema-registry.json")


def family_spec(family: str) -> dict[str, Any]:
    families = load_registry().get("schema_families", {})
    if family not in families:
        raise SchemaDispatchError(f"unknown schema_family {family!r}")
    return families[family]


def resolve_schema(family: str, version: str) -> Path:
    spec = family_spec(family)
    if version not in spec.get("supported", []):
        raise SchemaDispatchError(
            f"unsupported schema version for {family!r}: {version!r}"
        )
    filename = spec.get("schemas", {}).get(version)
    if not filename:
        raise SchemaDispatchError(
            f"schema registry has no exact schema for {family!r} {version!r}"
        )
    return ROOT / "schemas" / filename


def _looks_like_legacy_repository_policy(obj: dict[str, Any]) -> bool:
    required = {
        "ksss_version",
        "repository",
        "risk",
        "audit_profile",
        "controls",
        "schema_version",
    }
    return required.issubset(obj)


def identify_document(obj: dict[str, Any]) -> tuple[str, str, bool]:
    version = obj.get("schema_version")
    if not isinstance(version, str) or not version:
        raise SchemaDispatchError("missing schema_version")
    family = obj.get("schema_family")
    if family is None:
        if _looks_like_legacy_repository_policy(obj):
            spec = family_spec("repository-policy")
            if version not in spec.get("legacy_family_omission_allowed", []):
                raise SchemaDispatchError(
                    f"repository-policy {version!r} cannot omit schema_family"
                )
            return "repository-policy", version, True
        raise SchemaDispatchError("missing schema_family")
    if not isinstance(family, str) or not family:
        raise SchemaDispatchError("schema_family must be a non-empty string")
    return family, version, False


def _type_ok(value: Any, expected: str) -> bool:
    if expected == "object":
        return isinstance(value, dict)
    if expected == "array":
        return isinstance(value, list)
    if expected == "string":
        return isinstance(value, str)
    if expected == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if expected == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if expected == "boolean":
        return isinstance(value, bool)
    if expected == "null":
        return value is None
    return True


def validate_json_schema(
    value: Any,
    schema: dict[str, Any],
    *,
    path: str = "$",
) -> list[str]:
    errors: list[str] = []
    expected = schema.get("type")
    if expected is not None:
        allowed = expected if isinstance(expected, list) else [expected]
        if not any(_type_ok(value, item) for item in allowed):
            return [f"{path}: expected type {allowed}, got {type(value).__name__}"]

    if "const" in schema and value != schema["const"]:
        errors.append(f"{path}: expected constant {schema['const']!r}")
    if "enum" in schema and value not in schema["enum"]:
        errors.append(f"{path}: value {value!r} is not in enum")

    if isinstance(value, str):
        minimum = schema.get("minLength")
        if minimum is not None and len(value) < minimum:
            errors.append(f"{path}: string shorter than minLength={minimum}")
        pattern = schema.get("pattern")
        if pattern and re.search(pattern, value) is None:
            errors.append(f"{path}: string does not match pattern {pattern!r}")


    if isinstance(value, int) and not isinstance(value, bool):
        minimum = schema.get("minimum")
        if minimum is not None and value < minimum:
            errors.append(f"{path}: integer below minimum={minimum}")

    if isinstance(value, list):
        minimum = schema.get("minItems")
        if minimum is not None and len(value) < minimum:
            errors.append(f"{path}: array shorter than minItems={minimum}")
        item_schema = schema.get("items")
        if isinstance(item_schema, dict):
            for index, item in enumerate(value):
                errors.extend(
                    validate_json_schema(item, item_schema, path=f"{path}[{index}]")
                )

    if isinstance(value, dict):
        required = schema.get("required", [])
        for key in required:
            if key not in value:
                errors.append(f"{path}: missing required property {key!r}")
        properties = schema.get("properties", {})
        for key, child in value.items():
            if key in properties:
                errors.extend(
                    validate_json_schema(
                        child,
                        properties[key],
                        path=f"{path}.{key}",
                    )
                )
                continue
            additional = schema.get("additionalProperties", True)
            if additional is False:
                errors.append(f"{path}: unknown property {key!r}")
            elif isinstance(additional, dict):
                errors.extend(
                    validate_json_schema(
                        child,
                        additional,
                        path=f"{path}.{key}",
                    )
                )
    return errors


def _parse_timestamp(value: str, label: str, errors: list[str]) -> datetime | None:
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except Exception:
        errors.append(f"{label}: invalid ISO-8601 timestamp {value!r}")
        return None
    if parsed.tzinfo is None:
        errors.append(f"{label}: timestamp must include an explicit timezone")
        return None
    return parsed


def _secret_like_key(value: Any, path: str = "$") -> str | None:
    blocked = {
        "password",
        "passwd",
        "secret",
        "access_token",
        "api_key",
        "private_key",
        "credential",
        "credentials",
    }
    if isinstance(value, dict):
        for key, child in value.items():
            normalized = str(key).lower()
            if normalized in blocked:
                return f"{path}.{key}"
            found = _secret_like_key(child, f"{path}.{key}")
            if found:
                return found
    elif isinstance(value, list):
        for index, child in enumerate(value):
            found = _secret_like_key(child, f"{path}[{index}]")
            if found:
                return found
    return None


def validate_semantics(
    family: str,
    obj: dict[str, Any],
) -> list[str]:
    errors: list[str] = []
    if family == "repository-policy":
        if obj.get("controls", {}).get("risk_floor_enforcement") is not True:
            errors.append("repository-policy: risk floor cannot be disabled")


    elif family == "ksss-adoption":
        forbidden = {
            key
            for key in obj
            if "trust" in key.lower()
            or "signer" in key.lower()
            or "issuer" in key.lower()
        }
        if forbidden:
            errors.append(
                "ksss-adoption: trust belongs to trust-root, forbidden fields "
                f"{sorted(forbidden)}"
            )
        _parse_timestamp(
            obj.get("adopted_at", ""),
            "ksss-adoption.adopted_at",
            errors,
        )

    elif family == "trust-root":
        start = _parse_timestamp(
            obj.get("valid_from", ""),
            "trust-root.valid_from",
            errors,
        )
        end = _parse_timestamp(
            obj.get("expires_at", ""),
            "trust-root.expires_at",
            errors,
        )
        if start and end and start >= end:
            errors.append("trust-root: valid_from must be earlier than expires_at")

    elif family == "local-strengthening":
        controls = obj.get("controls", {})
        for control_id, change in controls.items():
            if not isinstance(change, dict):
                errors.append(
                    f"local-strengthening.{control_id}: control change must be an object"
                )
                continue
            unknown = set(change) - {"required", "parameters"}
            if unknown:
                errors.append(
                    f"local-strengthening.{control_id}: unknown fields {sorted(unknown)}"
                )
            if "required" in change and change["required"] is not True:
                errors.append(
                    f"local-strengthening.{control_id}: required may only be true"
                )
            params = change.get("parameters", {})
            if not isinstance(params, dict):
                errors.append(
                    f"local-strengthening.{control_id}.parameters must be an object"
                )
                continue

            for name, item in params.items():
                if not isinstance(item, dict) or set(item) != {"value"}:
                    errors.append(
                        f"local-strengthening.{control_id}.{name}: expected only value"
                    )

    if family in {"knowledge-record", "known-failure", "known-good-path"}:
        location = _secret_like_key(obj)
        if location:
            errors.append(
                f"{family}: secret-like field name rejected at {location}"
            )
        invalidated = set(obj.get("invalidated_by", []))
        unknown = invalidated - OFFICIAL_CHANGE_TYPES
        if unknown:
            errors.append(
                f"{family}: unknown invalidation types {sorted(unknown)}"
            )
        _parse_timestamp(
            obj.get("last_verified_at", ""),
            f"{family}.last_verified_at",
            errors,
        )
        if not obj.get("evidence_refs"):
            errors.append(f"{family}: evidence_refs must not be empty")
        if family == "known-good-path" and not obj.get("verification"):
            errors.append("known-good-path: verification must not be empty")

    return errors


def validate_document(obj: dict[str, Any]) -> list[str]:
    try:
        family, version, legacy_omission = identify_document(obj)
        schema_path = resolve_schema(family, version)
        schema = load_json(schema_path)
    except SchemaDispatchError as exc:
        return [str(exc)]

    candidate = obj
    if (
        family == "repository-policy"
        and not legacy_omission
        and "schema_family" in obj
    ):
        candidate = dict(obj)
        candidate.pop("schema_family", None)

    errors = validate_json_schema(candidate, schema)
    errors.extend(validate_semantics(family, obj))
    return errors


def assert_valid_document(obj: dict[str, Any]) -> tuple[str, str]:
    errors = validate_document(obj)
    if errors:
        raise SchemaDispatchError("; ".join(errors))
    family, version, _ = identify_document(obj)
    return family, version


__all__ = [
    "OFFICIAL_CHANGE_TYPES",
    "SchemaDispatchError",
    "assert_valid_document",
    "family_spec",
    "identify_document",
    "load_json",
    "load_registry",
    "resolve_schema",
    "validate_document",
    "validate_json_schema",
]
