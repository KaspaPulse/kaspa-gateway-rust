#!/usr/bin/env python3
from __future__ import annotations

import sys
from pathlib import Path
from typing import Any, Iterable

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from schema_registry import OFFICIAL_CHANGE_TYPES, assert_valid_document

FAILURE_FINGERPRINT_FIELDS = (
    "component",
    "operation_class",
    "failure_class",
    "resource_class",
    "runtime",
    "architecture_generation",
    "privilege_model",
    "dependency_fingerprint",
)
LEARNING_METRICS = (
    "KNOWLEDGE_HIT_RATE",
    "VALID_MATCH_REUSE_RATE",
    "REPEATED_INCIDENT_RATE",
    "TIME_TO_KNOWN_MATCH",
    "STALE_MATCH_RATE",
    "REGRESSION_CONTROL_COVERAGE",
    "ACTION_ITEM_CLOSURE_RATE",
)
DURABLE_PROTECTIONS = {
    "regression_test",
    "invariant",
    "policy",
    "known_failure_signature",
    "runbook",
    "ADR",
    "automated_control",
}


class KnowledgeError(ValueError):
    pass


def _context_matches(
    applies_when: dict[str, Any],
    context: dict[str, Any],
) -> bool:
    for key, expected in applies_when.items():
        if key not in context:
            return False
        actual = context[key]
        if isinstance(expected, list):
            if actual not in expected:
                return False
        elif actual != expected:
            return False
    return True


def record_reusable(
    record: dict[str, Any],
    *,
    context: dict[str, Any],
    active_change_types: Iterable[str] = (),
) -> bool:
    family, _ = assert_valid_document(record)
    if family not in {"knowledge-record", "known-failure", "known-good-path"}:
        raise KnowledgeError(f"unsupported knowledge family {family!r}")
    changes = set(active_change_types)
    unknown = changes - OFFICIAL_CHANGE_TYPES
    if unknown:
        raise KnowledgeError(f"unknown change types {sorted(unknown)}")
    if record.get("superseded_by"):
        return False
    if changes.intersection(record.get("invalidated_by", [])):
        return False
    return _context_matches(record.get("applies_when", {}), context)


def _failure_fingerprint_equal(
    left: dict[str, Any],
    right: dict[str, Any],
) -> bool:
    return all(left.get(key) == right.get(key) for key in FAILURE_FINGERPRINT_FIELDS)


def lookup_known_failures(
    records: Iterable[dict[str, Any]],
    *,
    fingerprint: dict[str, Any],
    context: dict[str, Any],
    active_change_types: Iterable[str] = (),
) -> list[dict[str, Any]]:
    missing = [key for key in FAILURE_FINGERPRINT_FIELDS if key not in fingerprint]
    if missing:
        raise KnowledgeError(f"failure fingerprint missing fields {missing}")
    matches = []
    for record in records:
        family, _ = assert_valid_document(record)
        if family != "known-failure":
            continue
        if not _failure_fingerprint_equal(
            record["failure_fingerprint"],
            fingerprint,
        ):
            continue
        if record_reusable(
            record,
            context=context,
            active_change_types=active_change_types,
        ):
            matches.append(record)
    return sorted(matches, key=lambda item: item["record_id"])


def lookup_known_good_paths(
    records: Iterable[dict[str, Any]],
    *,
    operation_class: str,
    context: dict[str, Any],
    active_change_types: Iterable[str] = (),
) -> list[dict[str, Any]]:
    matches = []
    for record in records:
        family, _ = assert_valid_document(record)
        if family != "known-good-path":
            continue
        if record["operation_class"] != operation_class:
            continue
        if record_reusable(
            record,
            context=context,
            active_change_types=active_change_types,
        ):
            matches.append(record)
    return sorted(matches, key=lambda item: item["record_id"])


def learning_closeout(
    *,
    service_status: str,
    learning_status: str,
    durable_protections: Iterable[str],
) -> str:
    if service_status not in {"OPEN", "DEGRADED", "RESOLVED"}:
        raise KnowledgeError(f"unknown SERVICE_STATUS={service_status}")
    if learning_status not in {"OPEN", "CLOSED"}:
        raise KnowledgeError(f"unknown LEARNING_STATUS={learning_status}")
    protections = set(durable_protections)
    unknown = protections - DURABLE_PROTECTIONS
    if unknown:
        raise KnowledgeError(f"unknown durable protections {sorted(unknown)}")
    if learning_status == "CLOSED" and not protections:
        raise KnowledgeError(
            "LEARNING_STATUS=CLOSED requires at least one durable protection"
        )
    return "PASS"


def repeated_known_failure_is_learning_failure(
    *,
    valid_match_existed: bool,
    failure_repeated: bool,
) -> bool:
    return valid_match_existed and failure_repeated


def validate_diagnosis_sequence(
    events: Iterable[str],
    *,
    high_severity_production_incident: bool = False,
) -> str:
    sequence = list(events)
    diagnosis = "DIAGNOSIS"
    lookup = "PREVIOUS_KNOWLEDGE_SEARCH=PASS"
    if diagnosis not in sequence:
        raise KnowledgeError("diagnosis sequence is missing DIAGNOSIS")
    diagnosis_index = sequence.index(diagnosis)
    if lookup not in sequence or sequence.index(lookup) >= diagnosis_index:
        raise KnowledgeError(
            "PREVIOUS_KNOWLEDGE_SEARCH=PASS must precede DIAGNOSIS"
        )
    if high_severity_production_incident:
        recovery = "CONTAIN_OR_RESTORE"
        if recovery not in sequence:
            raise KnowledgeError(
                "high-severity Production diagnosis requires CONTAIN_OR_RESTORE first"
            )
        recovery_index = sequence.index(recovery)
        lookup_index = sequence.index(lookup)
        if not recovery_index < lookup_index < diagnosis_index:
            raise KnowledgeError(
                "required order is CONTAIN_OR_RESTORE -> KNOWLEDGE SEARCH -> DIAGNOSIS"
            )
    return "PASS"


__all__ = [
    "DURABLE_PROTECTIONS",
    "FAILURE_FINGERPRINT_FIELDS",
    "KnowledgeError",
    "LEARNING_METRICS",
    "learning_closeout",
    "lookup_known_failures",
    "lookup_known_good_paths",
    "record_reusable",
    "repeated_known_failure_is_learning_failure",
    "validate_diagnosis_sequence",
]
